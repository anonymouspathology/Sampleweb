# Satoru Iwata Tribute
> FreeCodeCamp Webpage Project
> 
> Developed using HTML and CSS

## Developer
### Sean Miles
- Website: [seanmiles.dev](https://seanmiles.dev)
- GitHub: [@seanmiles](https://github.com/seanmiles)
